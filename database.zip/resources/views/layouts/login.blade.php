<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    @include('includes.loginstyle')
    @include('includes.bussines')
</head>

<body>
        @yield('content')


        
        <div class="text-center mt-5 ">
            <p class="footer-alt mb-5 ">Copyright 2020 • All right reserved • AskBuz</p>
        </div>
    </div>
</body>

</html>