

<?php $__env->startSection('title'); ?>
AskBuz Website | Let's consults with us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- home -->
    <div id="homepage" class="high"></div>
    <div class="row contentgrid">
    
    
    
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 ml-2 header1">
            <h3><?php echo e($item->title); ?></h3>
            <p><?php echo e($item->paragraph); ?></p>
            <a class="btn btn-primary tombolbiru sizetombol " href="#Bussines-Analysis-Page">Get Started</a>
            <a class="btn btn-outline-primary tombol sizetombol " href="#Forumpage">Get to Forum</a>
        </div>
        <div class="col-lg-7 header2 ml-auto mt-4">
            <img class="imageheader" src="<?php echo e(asset('frontend/img/' . $item->image)); ?>">

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
    <!-- akhir home -->

    <!-- service -->
    <div id="servicepage" class="high"></div>
    <div class="row">
        <div class="col-lg-12 textalign">
            <h3>Service Us</h3>
        </div>
    </div>
    <div class="row align-items-center">
        <div class="col-lg service-border service-text-paragraph">
            <img class="imagesservice" src="<?php echo e(asset('frontend/img/search.svg')); ?>">
            <h4>
                Bussines analysis
            </h4>
            <p class="mt-3">
                Designing processes and systems, assessing business models integrating them with technology.
            </p>

        </div>
        <div class="col-lg service-border service-text-paragraph">
            <img class="imagesservice" src="<?php echo e(asset('frontend/img/security.svg')); ?>">
            <h4 class="servicefont">
                Ui/Ux Design
            </h4>
            <p class="mt-3">
                Designing a user interface that is comfortable and user friendly
            </p>

        </div>
        <div class="col-lg service-border service-text-paragraph">
            <img class="imagesservice" src="<?php echo e(asset('frontend/img/bussines.svg')); ?>">
            <h4>
                IT Development
            </h4>
            <p>
                Develop a website or application that client wants
            </p>

        </div>
    </div>



    <!-- Akhir Service -->

    <!-- Awal About -->
    <div class="About" id="aboutpage" class="high1">

        <div class="row contentgrid">
            <div class="col-lg-5 mr-auto">
                <img class="imageset" src="<?php echo e(asset('frontend/img/photosabout.svg')); ?>">

            </div>
            <div class="col-lg-6 header1">

                <h3> About the AskBuz</h3>
                <p>The world continues to move towards global digitalization, leaving the conventional era eroded by mass modernization. We believe that climate change in business is bringing about a major shift in economic lane change. Everyone has lots of business ideas but few of those dreams have come true. Askbus Is Here to Be Your Solution And Business Partner. We provide various information and various types of business consulting according to current conditions. </p>
                <a class="btn btn-primary tombolbiru sizetombol tombolabout" href="<?php echo e(url('frontend/About/about.html')); ?>">View more</a>

            </div>

        </div>
    </div>


    <!-- Akhir About -->

    <!-- Forum -->
    <div class="Forum" id="Forumpage">
        <div class="row">
            <div class="col-lg-12 textalign">
                <h3>Forum & Discussion</h3>
            </div>
        </div>

        <div class="row">
            <div class="col-md-8 col-center m-auto">
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                    <!-- Carousel indicators -->
                    <ol class="carousel-indicators">
                        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                        <li data-target="#myCarousel" data-slide-to="1"></li>
                        <li data-target="#myCarousel" data-slide-to="2"></li>
                    </ol>
                    <!-- Wrapper for carousel items -->
                    <div class="carousel-inner">
                        <div class="item carousel-item active">

                            <div class="img-box"><img src="<?php echo e(asset('frontend/img/Ellipse 1.svg')); ?>"></div>
                            <p class="ParagraphForum">Selain dengan diiringi dengan usaha dan doa, kamu juga perlu motivasi ataupun dorongan untuk bangkitkan semangat berbisnis. Misalnya saja membaca pengalaman-pengalaman tokoh yang telah sukses berbisnis ataupun membaca kata-kata motivasi bangkitkan semangat berbisnis.</p>
                            <p class="overview"><b>Dhimas Aufarul Minan</b>, UX Writing</p>
                        </div>
                        <div class="item carousel-item">
                            <div class="img-box"><img src="<?php echo e(asset('frontend/img/Ellipse 3.svg')); ?>"></div>
                            <p class="ParagraphForum">Sebab terkadang risiko dan perencanaan yang terlalu lama seringkali menjadi penghambat seseorang untuk maju dan menjalankan usahanya. Untuk membangun bisnis dan menjadi entrepreneur, sebagai langkah awal seseorang harus menumbuhkan jiwa wirausaha.</p>
                            <p class="overview"><b>Muhammad Iqbal Fathan</b>, Web Design</p>
                        </div>
                        <div class="item carousel-item">
                            <div class="img-box"><img src="<?php echo e(asset('frontend/img/Ellipse 2.svg')); ?>"></div>
                            <p class="ParagraphForum">Jika ada waktu, kalian bisa bertukar pikiran dan berdiskusi mengenai hambatan yang menimpa bisnis Anda. Rekrut orang yang memiliki dedikasi, komitmen, dan integritas yang tinggi.</p>
                            <p class="overview"><b>Fihud Amien Wahidin</b>, Front End Developer</p>
                        </div>
                    </div>
                    <!-- Carousel controls -->
                    <a class="carousel-control left carousel-control-prev" href="#myCarousel" data-slide="prev">
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <a class="carousel-control right carousel-control-next" href="#myCarousel" data-slide="next">
                        <i class="fa fa-angle-right"></i>
                    </a>

                </div>
            </div>
        </div>
        <a class="btn btn-outline-primary tombol sizetombol" href="<?php echo e(url('frontend/Forum/Forum.html')); ?>">Discussion More</a>


    </div>





    <!-- akhir forum -->

     <!-- article -->

        <section class="wrapper" id="Articlepage">
            <div class="container-fostrap">
                <div class="content">
                    <div class="container">
                        <div class="col-lg-12 textalign mb-5 textareaarticle">
                            <h3>Article</h3>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-4">
                                <div class="card">
                                    <a class="img-card" href="">
                                        <img src="<?php echo e(asset('frontend/img/BussinesAnalysis.svg')); ?>" />
                                    </a>
                                    <div class="card-content">
                                        <h4 class="card-title">
                                            <a href=""> Apasih PMW itu?
                                          </a>
                                        </h4>
                                        <p class="">
                                            PMW adalah Kegiatan wirausaha mahasiswa ...
                                        </p>
                                    </div>
                                    <div class="card-read-more">
                                        <a href="" class="btn btn-link btn-block">
                                            Read More
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4">
                                <div class="card">
                                    <a class="img-card" href="">
                                        <img src="<?php echo e(asset('frontend/img/BussinesAnalysis.svg')); ?>" />
                                    </a>
                                    <div class="card-content">
                                        <h4 class="card-title">
                                            <a href=""> Kapan Pelaksanaan PMW?
                                          </a>
                                        </h4>
                                        <p class="">
                                            Setiap akhir atau awal semester ganjil...
                                        </p>
                                    </div>
                                    <div class="card-read-more">
                                        <a href="" class="btn btn-link btn-block">
                                            Read More
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4">
                                <div class="card">
                                    <a class="img-card" href="">
                                        <img src="<?php echo e(asset('frontend/img/BussinesAnalysis.svg')); ?>" />
                                    </a>
                                    <div class="card-content">
                                        <h4 class="card-title">
                                            <a href="">5 langkah jadi finalis dalam PMW
                                          </a>
                                        </h4>
                                        <p class="">
                                            PMW sendiri adalah kegiatan mahasiswa yang sangat di tunggu tunggu...
                                        </p>
                                    </div>
                                    <div class="card-read-more">
                                        <a href="" class="btn btn-link btn-block">
                                            Read More
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                 <a class="btn btn-outline-primary tombol sizetombol mt-3" href="<?php echo e(url('frontend/Forum/Forum.html')); ?>">More Article</a>
            </div>
           
        </section>


        <!-- Akhir Article -->

    <!-- Contact -->
    <div class="Contact">
        <div class="row " id="Bussines-Analysis-Page">
            <div class="col-lg-12 contactheader">
                <h3>"Consultant contact" <br> their field</h3>
            </div>
        </div>
        <div class="row textcontact ">
            <div class="col-lg-5 mr-auto hover01">
                <figure> <img class="imageset" src="<?php echo e(asset('frontend/img/BussinesAnalysis.svg')); ?>"></figure>
            </div>
            <div class="col-lg-5 header1 mr-auto ">
                <h3>Bussines Analysis</h3>
                <p>Business is something that requires environmental analysis, opportunities and various other aspects.
                    Business analysts have the responsibility to understand the structure, policies and production processes of a company or organization and recommend solutions.
                    This division is there to help clients to analyze more deeply related to the business that the client is running in order to grow and develop both in terms of technology and economy.
            </p>
                <a class="btn btn-outline-primary tombol sizetombol" href="<?php echo e(url('/BussinesAnalysisContact')); ?>">More Contact</a>
            </div>
        </div>


        <!-- akhir image -->

        <div class="row textcontact1" id="Ui/Ux-Design-Page">

            <div class="col-lg-5 order-lg-12  ml-auto hover01 ">

                <figure> <img class="imageset" src="<?php echo e(asset('frontend/img/BussinesGovernance.svg')); ?>"></figure>

            </div>
            <div class="col-lg-5 order-lg-1 header1 ml-auto">
                <h3>Ui/Ux Design</h3>
                <p>Having a business that has a weak level of digital design is a risky thing in the current digitalization era. This division will ensure system hirarcy and protect your business from threats that can affect the progress of your business so that computer system design and online activities will be created, protect business, protect assets, protect customer reputation and privacy, protect customer relationships.</p>
                <a class=" btn btn-outline-primary tombol sizetombol " href="<?php echo e(url('/SecurityContact')); ?>">More Contact</a>
            </div>
        </div>

        <div class="row textcontact" id="IT-Development-Page">
            <div class="col-lg-5 mr-auto hover01 ">
                <figure><img class="imageset" src="<?php echo e(asset('frontend/img/SecurityInBussines.svg')); ?>"></figure>
            </div>
            <div class="col-lg-5 header1 mr-auto  ">

                <h3>IT Development</h3>
                <p>The application of the principles of Good Business Governance is the foundation for the formation of a flexible and adaptive corporate system, structure and culture to changing competitive business environments and being able to build a reliable system of internal control and risk management so that your business is neatly organized
                This division is part of governance in carrying out activities so that business management can be better managed in its implementation </p>
                <a class="btn btn-outline-primary tombol sizetombol" href="<?php echo e(url('/GovernanceContact')); ?>">More Contact</a>

            </div>

        </div>



    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vikalonl/askbuz.vikal.online/resources/views/pages/home.blade.php ENDPATH**/ ?>