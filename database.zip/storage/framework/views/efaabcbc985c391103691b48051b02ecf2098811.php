<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="../index.html">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Contact Bussines Analysis</li>
    </ol>
</nav><?php /**PATH C:\xampp\htdocs\ProjectsBisnis\resources\views/includes/breadcrumb.blade.php ENDPATH**/ ?>