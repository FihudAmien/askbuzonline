<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php echo $__env->make('includes.loginstyle', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.bussines', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
        <?php echo $__env->yieldContent('content'); ?>


        
        <div class="text-center mt-5 ">
            <p class="footer-alt mb-5 ">Copyright 2020 • All right reserved • AskBuz</p>
        </div>
    </div>
</body>

</html><?php /**PATH /home/vikalonl/askbuz.vikal.online/resources/views/layouts/login.blade.php ENDPATH**/ ?>