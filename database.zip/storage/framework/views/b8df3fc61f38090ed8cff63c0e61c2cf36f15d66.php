<nav class="navbar navbar-expand-lg navbar-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#homepage"><img src="<?php echo e(url('frontend/img/LogoAskBuz.svg')); ?>"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false " aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ml-auto navtext">
                <a class="nav-link" href="#homepage">Home </a>
                <a class="nav-link" href="#servicepage">Service</a>
                <a class="nav-link" href="#aboutpage">About us</a>
                <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                      Informasi
                    </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#Forumpage">Forum & Discussion</a>
                            <a class="dropdown-item" href="#Articlepage">Article</a>
                        </div>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Contact
                </a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="#Bussines-Analysis-Page">Bussines Analysis</a>
                        <a class="dropdown-item" href="#Ui/Ux-Design-Page">Ui/Ux Design</a>
                        <a class="dropdown-item" href="#IT-Development-Page">IT Development</a>
                    </div>
                </li>
                <?php if(auth()->guard()->guest()): ?>
                
                <a class="btn btn-primary tombol"
                 href="<?php echo e(url('login')); ?>">Sign In</a>
                
                <?php endif; ?>
                
            
            </div>
            <?php if(auth()->guard()->check()): ?>
                <form action="<?php echo e(url('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button class="btn btn-outline-primary  tombol " type="submit">
                        
                        Logout
                    </button>
                </form>
                <?php endif; ?>
        </div>
    </div>
</nav><?php /**PATH /home/vikalonl/askbuz.vikal.online/resources/views/includes/navbar.blade.php ENDPATH**/ ?>