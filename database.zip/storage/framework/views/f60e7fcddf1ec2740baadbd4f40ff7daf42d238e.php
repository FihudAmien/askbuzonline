<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>

<body>

    <!-- Navbar -->
    <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Akhir navbar -->


    <!-- container -->
    <div class="container">
        
        <?php echo $__env->yieldContent('content'); ?>


        <!-- Footer -->
<footer class="footerset">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 mr-auto">
                <a href="#homepage"> <img src="<?php echo e(url('frontend/img/LogoAskBuz.svg')); ?>"> </a>
                <p class="paragraph-footer">let's start a business and upgrade <br> business to increase your traffic</p>

            </div>

            <div class="col-lg-3">

                <h6 class="footer-heading text-uppercase textset">For users</h6>
                <ul class="list-unstyled footer-link mt-4">
                    <li>
                        <a href="#Forumpage" ">Discussion with all </a></li>
                    <li><a href="#Bussines-Analysis-Page ">Contact with consultant</a></li>
                    <li><a href=" ">New Account</a></li>
                </ul>

            </div>

            <div class="col-lg-2 ">
                <h6 class="footer-heading text-uppercase textset ">Explore us</h6>
                <ul class="list-unstyled footer-link mt-4 ">
                    <li><a href="#homepage ">Homepage</a> </li>
                    <li><a href="#servicepage ">Services</a></li>
                    <li><a href="#aboutpage ">About us</a></li>
                    <li><a href=" ">Sign In</a></li>
                </ul>
            </div>

            <div class="col-lg-3 ">
                <h6 class="footer-heading text-uppercase textset ">Getting touch</h6>
                <ul class="list-unstyled footer-link mt-4 ">
                    <li><a href=" ">AskBuz@Support.com</a> </li>
                    <li><a href=" ">0129 - 3910 - 1393</a></li>
                    <li><a href=" ">AskBuz Indonesia </a></li>
                </ul>
            </div>
        </div>
    </div>

    <div class="text-center mt-5 ">
        <p class="footer-alt mb-5 ">Copyright 2020 • All right reserved • AskBuz</p>
    </div>
</footer>

<!-- Akhir Footer -->
        
    </div>

    <!-- akhir container -->

    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\ProjectsBisnis\resources\views/layouts/app.blade.php ENDPATH**/ ?>