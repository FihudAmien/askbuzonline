<?php $__env->startSection('title'); ?>
AskBuz Website | Let's consults with us
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Contact Security In Bussines</li>
    </ol>
</nav>
<div class="section paddinf-off tmm-team">
    <div class=" text-center colorheader ">
        <h3 class="text-center mt-2 mb-1">Team Security In Bussines</h3>
        <p class="text-center mb-4 ">Consultant contact their field</p>

    </div>
    <section class="tmm-container">
        <div class="tmm-row text-center mb-5">
            <div class="item-square-2">
                <div class="title">
                    <h3>Tatsurewa</h3>
                </div>
                <div class="face-container">
                    <div class="face"><img src="<?php echo e(url('frontend/Contact/imgSecurity/photo1.jpg')); ?>" /></div>
                </div>
                <div class="item-content">
                    <div class="footer">
                        <h4>Network Security</h4>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                            <li><a href="#"><i class="fas fa-envelope-open-text"></i></a></li>

                        </ul>
                    </div>
                </div>
            </div>
            <div class="item-square-2">
                <div class="title">
                    <h3>Steve Wesbene</h3>
                </div>
                <div class="face-container">
                    <div class="face"><img src="<?php echo e(url('frontend/Contact/imgSecurity/photo2.jpg')); ?>" /></div>
                </div>
                <div class="item-content">
                    <div class="footer">
                        <h4>Digital Anlysis</h4>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                            <li><a href="#"><i class="fas fa-envelope-open-text"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item-square-2">
                <div class="title">
                    <h3>Stephano Nathan</h3>
                </div>
                <div class="face-container">
                    <div class="face"><img src="<?php echo e(url('frontend/Contact/imgSecurity/photo3.jpg')); ?>"/></div>
                </div>
                <div class="item-content">
                    <div class="footer">
                        <h4>Chief Executive Officer</h4>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                            <li><a href="#"><i class="fas fa-envelope-open-text"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item-square-2">
                <div class="title">
                    <h3>Kimberly Jennie</h3>
                </div>
                <div class="face-container">
                    <div class="face"><img src="<?php echo e(url('frontend/Contact/imgSecurity/photo4.jpg')); ?>" /></div>
                </div>
                <div class="item-content">
                    <div class="footer">
                        <h4>Security Operation Center</h4>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                            <li><a href="#"><i class="fas fa-envelope-open-text"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="item-square-2">
                <div class="title">
                    <h3>Anny Magdeva</h3>
                </div>
                <div class="face-container">
                    <div class="face"><img src="<?php echo e(url('frontend/Contact/imgSecurity/photo5.jpg')); ?>" /></div>
                </div>
                <div class="item-content">
                    <div class="footer">
                        <h4>Penetration Testing</h4>
                        <ul class="social-icons">
                            <li><a href="#"><i class="fab fa-facebook-f icon"></i></a></li>
                            <li><a href="#"><i class="fa fa-whatsapp"></i></a></li>
                            <li><a href="#"><i class="fas fa-envelope-open-text"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script src="<?php echo e(url('frontend/scripts.js')); ?> "></script>


<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js " integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj " crossorigin="anonymous "></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js " integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN " crossorigin="anonymous "></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js " integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV " crossorigin="anonymous "></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectsBisnis\resources\views/pages/pageSb.blade.php ENDPATH**/ ?>