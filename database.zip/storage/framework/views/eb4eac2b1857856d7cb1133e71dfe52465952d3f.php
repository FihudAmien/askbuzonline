<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
          <h1 class="h3 mb-0 text-gray-800">Home</h1>
        </div>
       <?php if($errors->any()): ?>
       <div class="alert alert-danger">
           <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <li>
                       <?php echo e($error); ?>

                   </li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </ul>
       </div>
           
       <?php endif; ?>

       <div class="card shadow">
           <div class="card-body">
               <form action="<?php echo e(route('home-packages.update' , $item->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    
                    <label for="image">
                        Image Upload
                    </label>
                    <input type="file" class="form-control" name="image" value="<?php echo e($item->image); ?>">
                </div>
                <div class="form-group">
                    <label for="title">Title</label>
                    <input type="text" class="form-control" name="title" placeholder="fill in your title here" value="<?php echo e($item->title); ?>">
                </div>
                <div class="form-group">
                    <label for="paragraph">paragraph</label>
                    <textarea type="text" rows="10" class="d-block w-100 form-control" name="paragraph" placeholder="fill in your title paragraph" value="<?php echo e($item->paragraph); ?>"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    Edit Data
                </button>
               </form>
           </div>
      </div>
      <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProjectsBisnis\resources\views/pages/admin/home-packages/edit.blade.php ENDPATH**/ ?>