<link rel="stylesheet" href="<?php echo e(url('frontend/Contact/login.css')); ?>" />

<nav aria-label="breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li class="breadcrumb-item active" aria-current="page">Page Input Account</li>
    </ol>
</nav<?php /**PATH C:\xampp\htdocs\ProjectsBisnis\resources\views/includes/loginstyle.blade.php ENDPATH**/ ?>